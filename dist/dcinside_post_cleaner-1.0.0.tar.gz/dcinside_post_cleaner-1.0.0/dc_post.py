# dc_post.py
async def fetch_posts(page, hours_ago=1.0):
    # 게시글 목록 파싱 로직 분리
    # ...
    return []
